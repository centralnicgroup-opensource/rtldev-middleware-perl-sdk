# NAME

WebService::Hexonet - Namespace package for modules provided by [HEXONET](https://www.hexonet.net/).

# DESCRIPTION

This module is just used as namespace package for module provided by [HEXONET](https://www.hexonet.net/)
and does not provide any further functionality.

# AVAILABLE MODULES

Up to now we provide the following modules:

- [WebService::Hexonet::Connector](https://metacpan.org/pod/WebService%3A%3AHexonet%3A%3AConnector) - Connector Library for our Backend API.

# LICENSE AND COPYRIGHT

This program is licensed under the [MIT License](https://raw.githubusercontent.com/hexonet/perl-sdk/master/LICENSE).

# AUTHOR

[HEXONET GmbH](https://www.hexonet.net)
