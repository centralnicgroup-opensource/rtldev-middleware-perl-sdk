#!/bin/bash
make realclean && ./scripts/coverage.sh